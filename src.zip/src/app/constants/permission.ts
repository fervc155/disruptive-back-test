const Permission = {
	CREATE:'C',
	READ:'R',
	UPDATE:'U',
	DELETE:'D'
} as any

export default Permission